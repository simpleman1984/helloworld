define([], function () {
	
	// controller
	return ["$scope", function ($scope) {
		
		// properties
	    $scope.title = "这是标题引用";
	}];	
});
define(["map"], function () {

    // controller
    return ["$scope", function ($scope) {
        $scope.longitude = -119.34924430109;
        $scope.latitude  = -53.69477365887;

        $scope.buildList=[];

        $scope.updateBuildLocation= function(buildId){

        }
    }];
});